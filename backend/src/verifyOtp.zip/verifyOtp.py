import json
import base64
import os
import re
from typing import Any, Dict

import boto3

from otp import constant_time_equals, current_epoch_seconds, is_valid_email, json_response, normalize_email, otp_hmac_sha256_hex


_dynamodb = boto3.resource("dynamodb")

_OTP_RE = re.compile(r"^\d{6}$")
_HASH_RE = re.compile(r"^[a-f0-9]{16}$")


def _parse_body(event: Dict[str, Any]) -> Dict[str, Any]:
    raw_body = event.get("body")
    if raw_body is None:
        return {}
    if isinstance(raw_body, str):
        is_base64 = bool(event.get("isBase64Encoded"))
        if is_base64:
            decoded = base64.b64decode(raw_body).decode("utf-8")
            return json.loads(decoded) if decoded else {}
        return json.loads(raw_body) if raw_body else {}
    if isinstance(raw_body, dict):
        return raw_body
    return {}


def lambda_handler(event, context):
    body = _parse_body(event)
    email = body.get("email", "").strip()
    otp = body.get("otp", "").strip()
    unique_hash = body.get("uniqueHash", "").strip()

    # Validate email
    if not isinstance(email, str) or not is_valid_email(email):
        return json_response(400, {"message": "Invalid email"})

    # Validate OTP format
    if not isinstance(otp, str) or not _OTP_RE.match(otp):
        return json_response(400, {"message": "Invalid OTP format"})

    # Validate unique hash format
    if not isinstance(unique_hash, str) or not _HASH_RE.match(unique_hash):
        return json_response(400, {"message": "Invalid unique hash"})

    email_norm = normalize_email(email)

    otp_ttl_seconds = int(os.environ.get("OTP_TTL_SECONDS", "300"))
    otp_hash_key = os.environ.get("OTP_HASH_KEY")
    if not otp_hash_key:
        return json_response(500, {"message": "Server error"})

    otp_table_name = os.environ.get("OTP_TABLE_NAME")
    if not otp_table_name:
        return json_response(500, {"message": "Server error"})

    table = _dynamodb.Table(otp_table_name)
    result = table.get_item(Key={"email": email_norm})
    item = result.get("Item")

    # Treat missing records as invalid OTP (prevents enumeration)
    if not item:
        return json_response(401, {"message": "Invalid or expired OTP"})

    # Verify unique hash matches
    stored_hash = item.get("uniqueHash")
    if not constant_time_equals(stored_hash, unique_hash):
        return json_response(401, {"message": "Invalid or expired OTP"})

    # Check if OTP has expired
    created_at = int(item.get("createdAt", 0))
    if created_at <= 0 or current_epoch_seconds() > created_at + otp_ttl_seconds:
        return json_response(401, {"message": "Invalid or expired OTP"})

    # Verify OTP hash
    expected_hash = otp_hmac_sha256_hex(hash_key=otp_hash_key, email=email_norm, otp=otp)
    actual_hash = item.get("otpHash")
    if not constant_time_equals(actual_hash, expected_hash):
        return json_response(401, {"message": "Invalid or expired OTP"})

    # Extract user details before deletion
    user_name = item.get("name", "User")
    user_city = item.get("city", "")
    timestamp = item.get("timestamp", "")

    # OTP verified successfully; remove the record
    table.delete_item(Key={"email": email_norm})

    return json_response(200, {
        "status": "Success",
        "message": "OTP verified successfully",
        "user": {
            "email": email_norm,
            "name": user_name,
            "city": user_city,
            "timestamp": timestamp,
        },
    })

